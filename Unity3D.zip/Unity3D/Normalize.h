#include "Quanternion.h"

float NormalizeAngle(float angle){
    while (angle>360)
        angle -= 360;
    while (angle<0)
        angle += 360;
    return angle;
}

Vector3 NormalizeAngles(Vector3 angles){
    angles.X = NormalizeAngle(angles.X);
    angles.Y = NormalizeAngle(angles.Y);
    angles.Z = NormalizeAngle(angles.Z);
    return angles;
}

Vector3 ToEulerRad(Quaternion q1){
    float Rad2Deg = 360.0f / (M_PI * 2.0f);
    float sqw = q1.W * q1.W;
    float sqx = q1.X * q1.X;
    float sqy = q1.Y * q1.Y;
    float sqz = q1.Z * q1.Z;
    float unit = sqx + sqy + sqz + sqw;
    float test = q1.X * q1.W - q1.Y * q1.Z;
    Vector3 v;

    if (test > 0.4995f * unit) {
        v.Y = 2.0f * atan2f (q1.Y, q1.X);
        v.X = M_PI / 2.0f;
        v.Z = 0;
        return NormalizeAngles(v * Rad2Deg);
    }

    if (test<-0.4995f*unit) {
        v.Y = -2.0f * atan2f (q1.Y, q1.X);
        v.X = -M_PI / 2.0f;
        v.Z = 0;
        return NormalizeAngles(v * Rad2Deg);
    }

    Quaternion q(q1.W, q1.Z, q1.X, q1.Y);
    v.Y = atan2f(2.0f * q.X * q.W + 2.0f * q.Y * q.Z, 1 - 2.0f * (q.Z * q.Z + q.W * q.W)); // yaw
    v.X = asinf(2.0f * (q.X * q.Z - q.W * q.Y)); // pitch
    v.Z = atan2f(2.0f * q.X * q.Y + 2.0f * q.Z * q.W, 1 - 2.0f * (q.Y * q.Y + q.Z * q.Z)); // roll
    return NormalizeAngles(v * Rad2Deg);
}